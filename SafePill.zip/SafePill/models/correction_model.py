def correct_drug_name(text):

    # TODO: 실제 파인튜닝된 모델 로딩
    # model = AutoModelForSeq2SeqLM.from_pretrained("your-finetuned-model")

    # 현재는 간단한 규칙 기반 더미 처리
    correction_dict = {
        "타이레롤": "타이레놀",
        "게보린느": "게보린"
    }

    return correction_dict.get(text, text)