import io

async def extract_text_from_image(image):

    # ------------------------------------------
    # 현재는 테스트용 더미 반환
    # ------------------------------------------
    return "타이레롤"

    # ==========================================
    # 🔽 아래는 EasyOCR 실제 적용 코드 (활성화 예정)
    # ==========================================

    """
    contents = await image.read()
    np_image = np.array(Image.open(io.BytesIO(contents)))

    results = reader.readtext(np_image, detail=0)

    text = " ".join(results)

    return text.strip()
    """