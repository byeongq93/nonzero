from fastapi import FastAPI, UploadFile, File, Form
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware  # 💡 1. 허가증 도구 가져오기
from typing import List

from services.ocr_service import extract_text_from_image
from models.correction_model import correct_drug_name
from services.db_service import check_drug_interaction
from services.rag_service import generate_explanation

app = FastAPI()

# 💡 2. 프론트엔드 접속을 허락하는 허가증 달아주기 (이 7줄 추가!)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ------------------------------------
# 신호등 이미지 정적 파일 제공
# ------------------------------------
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.post("/analyze")
async def analyze_drug(
    image: UploadFile = File(...),
    current_drugs: List[str] = Form(default=[])
):

    raw_text = await extract_text_from_image(image)

    corrected_name = correct_drug_name(raw_text)

    db_result = check_drug_interaction(corrected_name, current_drugs)

    explanation = generate_explanation(corrected_name, db_result["risk"])

    return {
        "corrected_name": corrected_name,
        "risk": db_result["risk"],
        "reason": db_result["reason"],
        "explanation": explanation
    }